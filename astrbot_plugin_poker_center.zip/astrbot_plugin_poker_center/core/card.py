from enum import Enum
import emoji

class Suit(Enum):
    SPADES = "♠️"
    HEARTS = "♥️"
    DIAMONDS = "♦️"
    CLUBS = "♣️"

class Rank(Enum):
    TWO = ("2", 2)
    THREE = ("3", 3)
    FOUR = ("4", 4)
    FIVE = ("5", 5)
    SIX = ("6", 6)
    SEVEN = ("7", 7)
    EIGHT = ("8", 8)
    NINE = ("9", 9)
    TEN = ("10", 10)
    JACK = ("J", 10)
    QUEEN = ("Q", 10)
    KING = ("K", 10)
    ACE = ("A", 11)

class Card:
    def __init__(self, suit: Suit, rank: Rank):
        self.suit = suit
        self.rank = rank
    
    def __str__(self):
        return f"{self.rank.value[0]}{self.suit.value}"
    
    def emoji(self):
        # Unicode扑克牌表情
        base = 0x1F0A0
        suit_offset = {
            Suit.SPADES: 0,
            Suit.HEARTS: 1,
            Suit.DIAMONDS: 2,
            Suit.CLUBS: 3
        }
        rank_offset = {
            Rank.ACE: 1,
            Rank.TWO: 2,
            Rank.THREE: 3,
            Rank.FOUR: 4,
            Rank.FIVE: 5,
            Rank.SIX: 6,
            Rank.SEVEN: 7,
            Rank.EIGHT: 8,
            Rank.NINE: 9,
            Rank.TEN: 10,
            Rank.JACK: 11,
            Rank.QUEEN: 12,
            Rank.KING: 13
        }
        return chr(base + suit_offset[self.suit] * 16 + rank_offset[self.rank])