import random
from typing import List

class Deck:
    def __init__(self, jokers=False):
        self.cards = []
        for suit in Suit:
            for rank in Rank:
                self.cards.append(Card(suit, rank))
        if jokers:
            self.cards.extend([Card(None, "JOKER"), Card(None, "JOKER")])
        self.shuffle()
    
    def shuffle(self):
        random.shuffle(self.cards)
    
    def deal(self, count: int) -> List[Card]:
        return [self.cards.pop() for _ in range(count)]
    
    def reset(self):
        self.__init__()