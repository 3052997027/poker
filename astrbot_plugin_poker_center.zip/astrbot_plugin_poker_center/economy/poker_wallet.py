class PokerWallet:
    @filter.command("chips")
    async def show_chips(self, event: AstrMessageEvent):
        balance = await self.get_balance(event.get_sender_id())
        yield event.plain_result(
            f"💰 你的筹码: \n"
            f"• ${balance} 总筹码\n"
            f"• 今日签到: {'✅已领取' if await self.checked_in(event.get_sender_id()) else '❌未领取'}"
        )
    
    @filter.command("daily")
    async def daily_bonus(self, event: AstrMessageEvent):
        # 每日签到领100筹码
        pass