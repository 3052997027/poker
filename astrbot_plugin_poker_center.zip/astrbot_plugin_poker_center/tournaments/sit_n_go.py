class SitAndGoTournament:
    @filter.command("sit_n_go")
    async def join_tournament(self, event: AstrMessageEvent):
        # 6人快速锦标赛
        # 买入: 100筹码
        # 盲注随时间递增
        # 奖励分配: 1st-60%, 2nd-30%, 3rd-10%
        pass