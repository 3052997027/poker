# games/omaha.py
class OmahaGame:
    @filter.command("omaha")
    async def start_omaha(self, event: AstrMessageEvent, bet: int = 30):
        """奥马哈：每人4张手牌，必须用2张+3张公共牌"""
        deck = Deck()
        player_hand = deck.deal(4)  # 4张手牌
        bot_hand = deck.deal(4)
        
        # 公共牌（同德州）
        flop = deck.deal(3)
        turn = deck.deal(1)
        river = deck.deal(1)
        community = flop + turn + river
        
        yield event.plain_result(
            f"🎯 奥马哈开始！\n"
            f"手牌: {self._format_cards(player_hand)}\n"
            f"必须用2张手牌+3张公共牌组合"
        )
        # 后续流程类似德州...