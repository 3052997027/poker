# games/chinese_poker.py
class ChinesePokerGame:
    @filter.command("poker13", alias={"十三张"})
    async def start_13(self, event: AstrMessageEvent, bet: int = 50):
        """十三张（比牌型大小）"""
        deck = Deck()
        hand = deck.deal(13)
        
        yield event.plain_result(
            f"🎯 十三张开始！\n"
            f"手牌: {self._format_cards(hand)}\n"
            f"💡 请用 /arrange [前中后] 分三组牌\n"
            f"例如: /arrange 3 5 5"
        )
        
        @session_waiter(timeout=60)
        async def arrange_cards(controller: SessionController, event: AstrMessageEvent):
            # 解析玩家分组
            # 与AI比牌型
            # 计算胜负...
            pass