class BlackjackGame:
    def __init__(self, context, wallet):
        self.context = context
        self.wallet = wallet
    
    @filter.command("blackjack", alias={"21", "bj"})
    async def start_blackjack(self, event: AstrMessageEvent, bet: int = 10):
        user_id = event.get_sender_id()
        
        # 检查筹码
        if not await self.wallet.deduct_chips(user_id, bet):
            yield event.plain_result("❌ 筹码不足！需要至少10筹码")
            return
        
        deck = Deck()
        player_hand = deck.deal(2)
        dealer_hand = deck.deal(2)
        
        # 显示初始手牌
        hand_display = self._format_hand(player_hand, "你的手牌")
        hand_display += f"\n🂠 明牌: {dealer_hand[0]}"
        
        yield event.plain_result(
            f"🎯 21点游戏开始！\n"
            f"下注: {bet}筹码\n"
            f"{hand_display}\n"
            f"💡 发送 /hit 要牌 或 /stand 停牌"
        )
        
        @session_waiter(timeout=30)
        async def game_handler(controller: SessionController, event: AstrMessageEvent):
            action = event.message_str.strip().lower()
            
            if action == "/hit":
                player_hand.extend(deck.deal(1))
                if self._calculate_score(player_hand) > 21:
                    await event.send("💥 爆牌了！你输了")
                    controller.stop()
                    return
                
                await event.send(self._format_hand(player_hand, "新手牌"))
                controller.keep(timeout=30)
                
            elif action == "/stand":
                # 庄家逻辑
                while self._calculate_score(dealer_hand) < 17:
                    dealer_hand.extend(deck.deal(1))
                
                result = self._determine_winner(player_hand, dealer_hand)
                if result == "win":
                    await self.wallet.add_chips(user_id, bet * 2)
                    await event.send(f"🎉 你赢了！获得{bet*2}筹码")
                elif result == "push":
                    await self.wallet.add_chips(user_id, bet)
                    await event.send("🤝 平局！退还筹码")
                else:
                    await event.send("😢 你输了！")
                
                controller.stop()
        
        try:
            await game_handler(event)
        except TimeoutError:
            yield event.plain_result("⏰ 游戏超时！")
    
    def _calculate_score(self, hand: List[Card]) -> int:
        score = sum(card.rank.value[1] for card in hand)
        # A处理
        aces = sum(1 for card in hand if card.rank == Rank.ACE)
        while score > 21 and aces:
            score -= 10
            aces -= 1
        return score
    
    def _format_hand(self, hand: List[Card], title: str) -> str:
        cards = " ".join(card.emoji() for card in hand)
        score = self._calculate_score(hand)
        return f"{title}: {cards} (点数: {score})"