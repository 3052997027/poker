# 文件路径: astrbot_plugin_poker_center/utils/renderer.py
from astrbot.api.star import Star
from PIL import Image, ImageDraw, ImageFont
import io
import base64

class CardRenderer:
    def __init__(self):
        self.width = 200
        self.height = 300
    
    async def render_hand(self, cards, title="手牌"):
        """AstrBot内置渲染方式"""
        html = self._generate_html(cards, title)
        return await self.html_render(html)  # Star类的方法
    
    def _generate_html(self, cards, title):
        return f"""
        <div style="background: linear-gradient(135deg, #0f5132, #198754); 
                    padding: 30px; border-radius: 20px; text-align: center;">
            <h2 style="color: white; margin-bottom: 20px;">{title}</h2>
            <div style="display: flex; gap: 15px; justify-content: center; flex-wrap: wrap;">
                {self._card_html(cards)}
            </div>
        </div>
        """
    
    def _card_html(self, cards):
        cards_html = ""
        for card in cards:
            color = "#dc3545" if card.suit.name in ['HEARTS', 'DIAMONDS'] else "#212529"
            cards_html += f"""
            <div style="background: white; width: 120px; height: 170px; 
                        border-radius: 10px; padding: 10px; box-shadow: 0 4px 8px rgba(0,0,0,0.3);">
                <div style="color: {color}; font-size: 24px; font-weight: bold;">
                    {card.rank.value[0]}
                </div>
                <div style="color: {color}; font-size: 48px; text-align: center; margin: 10px 0;">
                    {card.suit.value}
                </div>
            </div>
            """
        return cards_html